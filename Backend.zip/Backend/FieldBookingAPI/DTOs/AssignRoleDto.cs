public class AssignRoleDto
{
    public int UserId { get; set; }
    public string Role { get; set; } = null!;
}