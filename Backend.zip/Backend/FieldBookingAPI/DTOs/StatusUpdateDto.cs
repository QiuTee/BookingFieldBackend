namespace FieldBookingAPI.DTOs
{
    public class StatusUpdateDto
    {
        public string? Status { get; set; }
        public string? ProcessStatus{ get; set; }
    }
}