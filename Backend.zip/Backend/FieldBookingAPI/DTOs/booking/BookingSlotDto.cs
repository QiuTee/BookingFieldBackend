namespace FieldBookingAPI.DTOs
{
    public class BookingSlotDto
    {
        public string SubField { get; set; } = null!;
        public string Time { get; set; } = null!;
    }
}
