
namespace FieldBookingAPI.DTOs
{
    public class ApplyVoucherDto
    {
        public string Code { get; set; } = null!;
        public int TotalPrice { get; set; } = 0;
    }
}
